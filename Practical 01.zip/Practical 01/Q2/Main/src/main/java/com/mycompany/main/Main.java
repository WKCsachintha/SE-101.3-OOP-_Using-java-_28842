
package com.mycompany.main;

public class Main 
{

    public static void main(String[] args) 
    {
    String name = "WKC SACHINTHA";
    String degreeProgram = "COMPUTER SCEINCE";
    System.out.println(name);
    System.out.println(degreeProgram);
    }
}
