
package com.mycompany.main;

public class Main 
{

    public static void main(String[] args) 
    {
       Monster M1 = new Monster(123,"line");
    }
}
