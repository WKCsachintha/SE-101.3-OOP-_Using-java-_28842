

package com.mycompany.main;


public class Monster extends Item 
{
    public Monster(int location, String description) {
    super(location, description);
    } 
}
