/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.testinheritance;

/**
 *
 * @author asus
 */
public class SuperC extends SuperB 
{
    @Override
    public void triple() {
        
        x += 3;
    }

    public void quadruple() {
       
        x *= 4;
    }
}
