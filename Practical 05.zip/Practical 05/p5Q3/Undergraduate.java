package com.mycompany.p5q3;

public class Undergraduate extends Student //final class can never be a sub class
{
    @Override
    void display()
    {
      //A final method cannot be overriding  
    }
    
}
