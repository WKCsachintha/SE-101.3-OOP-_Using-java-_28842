package com.mycompany.p5q1;
public interface MyFirstInterface
{
    int x = 10; // Variable declaration

    void display(); // Abstract method declaration
}
