package com.mycompany.p5q2;

public interface Speaker
{
    void speak();
    
}
