package com.mycompany.p5q2;

public class Lecturer implements Speaker
{
    @Override
    public void speak()
    {
        System.out.println("As a lecturer, I conduct lectures");
    }
}
